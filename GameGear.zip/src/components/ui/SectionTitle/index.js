export { default } from './SectionTitle'
